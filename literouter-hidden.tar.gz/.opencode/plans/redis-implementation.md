# LiteRouter Redis Implementation Plan

## Status: READY FOR EXECUTION

---

## Intention & Deliverables

**Goal**: Convert LiteRouter from TypeScript/Bun to Python with Redis as the centralized distributed state store, enabling seamless key rotation across multiple instances.

**Deliverables**:
1. Python FastAPI server replacing Bun HTTP server (same port 7766)
2. Redis-backed state: router counters, key cooldowns/quarantines, rate limiting, request queue, metrics
3. Embedding cache layer (BGE-M3) using Redis
4. Graceful degradation when Redis is unavailable
5. Same OpenAI-compatible `/v1/chat/completions` API
6. Same `/health` endpoint with enhanced Redis status
7. Doctor/preflight test utilities
8. Startup scripts and documentation

---

## Redis Connection Details (VERIFIED)

- **Host**: `10.32.34.243`
- **Port**: `12000`
- **Password**: `jF&Q7ooAa^h` (regular caret `^`, NOT modifier letter `ˆ`)
- **Version**: Redis 8.6.2 standalone
- **Python client**: `redis>=5.0.0` (redis-py)
- **Existing data**: `mcpmart:key_status` hash with 20 Gemini API keys

---

## Architecture

```
┌─────────────────────────────────────────────────────────────┐
│                    FastAPI Server (port 7766)               │
│  /v1/chat/completions  /health  /metrics                    │
├─────────────────────────────────────────────────────────────┤
│  ┌──────────┐  ┌──────────┐  ┌──────────┐  ┌────────────┐  │
│  │  Config   │  │  Router   │  │ Rate Lim │  │   Queue    │  │
│  │  (.env)   │  │  State    │  │  (Lua)   │  │  (Redis)   │  │
│  └────┬─────┘  └────┬─────┘  └────┬─────┘  └─────┬──────┘  │
│       │              │             │               │         │
│  ┌────┴──────────────┴─────────────┴───────────────┴──────┐ │
│  │                  Redis Client Layer                     │ │
│  │  (sync + async, graceful degradation, connection pool)  │ │
│  └────────────────────────┬────────────────────────────────┘ │
└───────────────────────────┼─────────────────────────────────┘
                            │
              ┌─────────────┼─────────────┐
              │  Redis Enterprise          │
              │  10.32.34.243:12000        │
              │                            │
              │  literouter:counter:*       │
              │  literouter:cooldown:*      │
              │  literouter:quarantine:*    │
              │  literouter:ratelimit:*     │
              │  literouter:queue:*         │
              │  literouter:metrics:*       │
              │  literouter:embed:*         │
              │  literouter:query:*         │
              └────────────────────────────┘
```

---

## Redis Key Schema

| Component | Key Pattern | Type | TTL |
|-----------|-------------|------|-----|
| Router counters | `literouter:counter:{provider}` | STRING | none |
| Key cooldowns | `literouter:cooldown:{provider}:{sha256}` | STRING | 1h |
| Quarantined keys | `literouter:quarantine:{provider}` | SET | none |
| Rate limiter | `literouter:ratelimit:{provider}` | STRING | none |
| Request queue | `literouter:queue` | LIST | none |
| Processing jobs | `literouter:processing` | ZSET | 5min |
| Job metadata | `literouter:job:{id}` | HASH | 1h |
| Metrics | `literouter:metrics:{type}` | HASH | none |
| Embedding cache | `literouter:embed:{sha256}` | STRING | 24h |
| Query cache | `literouter:query:{sha256}` | STRING | 1h |

---

## Project Structure

```
literouter/
├── .env.example
├── pyproject.toml
├── uv.lock
├── src/
│   ├── __init__.py
│   ├── main.py              # FastAPI app entry point
│   ├── config.py            # .env + Pydantic config loader
│   ├── redis_client.py      # Sync + async Redis clients
│   ├── router.py            # Round-robin key rotation (Redis-backed)
│   ├── rate_limiter.py      # Rate limiter with Lua scripts
│   ├── queue.py             # Redis-backed request queue
│   ├── metrics.py           # Redis-backed metrics
│   ├── models.py            # Pydantic request/response models
│   ├── gemini.py            # OpenAI <-> Gemini transformation
│   ├── doctor.py            # Health check / diagnostics
│   └── test.py              # Preflight key validation
├── scripts/
│   ├── start.sh
│   └── restart.sh
└── tests/
    └── test_*.py
```

---

## Task Delegation Plan

### Subagent 1: Infrastructure (Tasks 2, 3, 8)
- Create `pyproject.toml`, `.env.example`, directory structure
- Implement `redis_client.py` (sync + async, graceful degradation)
- Implement `config.py` (.env + Pydantic settings)

### Subagent 2: Core Logic (Tasks 4, 5, 7)
- Implement `router.py` (round-robin with Redis counters, cooldowns, quarantines)
- Implement `rate_limiter.py` (Lua script for atomic rate limiting)
- Implement `metrics.py` (Redis HASH-based metrics)

### Subagent 3: Queue & Server (Tasks 6, 9, 10)
- Implement `queue.py` (Redis LIST + ZSET visibility timeout)
- Implement `main.py` (FastAPI server, auth, routing)
- Implement `gemini.py` (OpenAI <-> Gemini transformation)
- Implement `models.py` (Pydantic request/response schemas)

### Subagent 4: Utilities & Testing (Tasks 11, 12, 13, 14)
- Implement `doctor.py` and `test.py`
- Implement `embed_cache.py` (embedding cache layer)
- Write integration tests
- Create startup scripts and README

### Coordinator (Me):
- Orchestrate subagents in dependency order
- Review and integrate all outputs
- Run end-to-end validation
- Handle cross-cutting concerns

---

## Execution Order

```
Phase 1 (Infra) ──┐
                   ├── Phase 2 (Core) ──┐
Phase 1 (Infra) ──┘                     ├── Phase 3 (Server) ── Phase 4 (Test)
                   ┌────────────────────┘
Phase 1 (Infra) ──┘
```

1. **Phase 1**: Scaffolding + Redis client + Config (all subagents depend on this)
2. **Phase 2**: Router + Rate limiter + Metrics (parallel)
3. **Phase 3**: Queue + Server + Gemini (depends on Phase 2)
4. **Phase 4**: Tests + Doctor + Embed cache + Scripts (depends on Phase 3)

---

## Assumptions Verified

- [x] Redis accessible on port 12000 (confirmed: PONG received)
- [x] Password `jF&Q7ooAa^h` works (confirmed: AUTH OK)
- [x] Redis 8.6.2 standalone (confirmed via INFO)
- [x] Python 3.14 available (confirmed)
- [x] redis-py installed (v7.4.0)
- [x] Existing `mcpmart:key_status` hash pattern understood
- [x] baziRAG `redis_cache.py` pattern studied for graceful degradation

## User Decisions

- [x] Config format: `.env` + Pydantic (not config.json)
- [x] Server port: 7766 (same as Bun version)
- [x] Queue model: Sequential (one at a time)
