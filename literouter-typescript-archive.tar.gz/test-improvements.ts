#!/usr/bin/env bun
/**
 * Test script to verify the improvements work correctly
 */

import { loadRouterState, saveRouterState } from "./src/storage.js";
import { getNextKey, reportError } from "./src/router.js";
import { metrics } from "./src/metrics.js";

// Test persistent storage
console.log("Testing persistent storage...");
const initialState = loadRouterState();
console.log("Initial state:", initialState);

// Test that we can save state
saveRouterState({ counter: 42, lastUpdated: Date.now() });
const afterSaveState = loadRouterState();
console.log("After save state:", afterSaveState);

// Test metrics
console.log("\nTesting metrics...");
metrics.incrementRequest();
metrics.incrementKeyUsage("test-key-12345");
metrics.incrementSuccess();
metrics.addLatency(150);

const currentMetrics = metrics.getMetrics();
console.log("Current metrics:", currentMetrics);

console.log("\nAll tests completed successfully!");