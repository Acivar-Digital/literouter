#!/bin/bash
# bun_restart.sh — manual restart trigger
# Kills the existing tmux session (if any) and starts fresh.

SESSION="literouter"
PROJECT_DIR="$(cd "$(dirname "$0")" && pwd)"

tmux kill-session -t "$SESSION" 2>/dev/null
sleep 0.5
tmux new-session -d -s "$SESSION" -c "$PROJECT_DIR" 'bun start'
echo "Restarted bun start in tmux session '$SESSION'."
