#!/usr/bin/env bun
/**
 * src/rate_limiter.test.ts
 *
 * Unit tests for ProviderRateLimiter static class.
 *
 * Run: bun test src/rate_limiter.test.ts
 */

import { describe, it, expect, beforeEach, mock } from "bun:test";
import { ProviderRateLimiter } from "./rate_limiter.js";

describe("ProviderRateLimiter", () => {
  beforeEach(() => {
    // Reset state between tests
    ProviderRateLimiter.reset("openrouter");
    ProviderRateLimiter.reset("gemini");
    ProviderRateLimiter.reset("openai");
  });

  describe("canCall", () => {
    it("returns ready=true immediately for first call (no prior markCall)", () => {
      const result = ProviderRateLimiter.canCall("openrouter", 3000);
      expect(result.ready).toBe(true);
      expect(result.waitMs).toBe(0);
    });

    it("returns ready=true after enough time has elapsed", () => {
      // Simulate a call 4000ms ago
      const originalNow = Date.now;
      const baseTime = originalNow();

      // Simulate time passing back in time: mark at baseTime, then advance
      Date.now = mock(() => baseTime);
      ProviderRateLimiter.markCall("openrouter");

      // Now pretend 4000ms have passed
      Date.now = mock(() => baseTime + 4000);

      const result = ProviderRateLimiter.canCall("openrouter", 3000);
      Date.now = originalNow;

      expect(result.ready).toBe(true);
      expect(result.waitMs).toBe(0);
    });

    it("returns ready=false and correct waitMs when called too soon", () => {
      const originalNow = Date.now;
      const baseTime = originalNow();

      // Mark a call at baseTime
      Date.now = mock(() => baseTime);
      ProviderRateLimiter.markCall("openrouter");

      // Only 1000ms elapsed, but minDelay is 3000ms
      Date.now = mock(() => baseTime + 1000);

      const result = ProviderRateLimiter.canCall("openrouter", 3000);
      Date.now = originalNow;

      expect(result.ready).toBe(false);
      expect(result.waitMs).toBeGreaterThan(0);
      // Should wait ~2000ms more
      expect(result.waitMs).toBeGreaterThanOrEqual(1990);
      expect(result.waitMs).toBeLessThanOrEqual(2010);
    });

    it("returns waitMs=0 exactly at the boundary", () => {
      const originalNow = Date.now;
      const baseTime = originalNow();

      Date.now = mock(() => baseTime);
      ProviderRateLimiter.markCall("openrouter");

      // Exactly 3000ms later
      Date.now = mock(() => baseTime + 3000);

      const result = ProviderRateLimiter.canCall("openrouter", 3000);
      Date.now = originalNow;

      expect(result.ready).toBe(true);
      expect(result.waitMs).toBe(0);
    });

    it("tracks different providers independently", () => {
      const originalNow = Date.now;
      const baseTime = originalNow();

      // Mark openrouter but not gemini
      Date.now = mock(() => baseTime);
      ProviderRateLimiter.markCall("openrouter");

      // 500ms later
      Date.now = mock(() => baseTime + 500);

      // Gemini should be ready (first call)
      const geminiResult = ProviderRateLimiter.canCall("gemini", 2000);
      expect(geminiResult.ready).toBe(true);

      // OpenRouter should NOT be ready (500ms < 3000ms minDelay)
      const orResult = ProviderRateLimiter.canCall("openrouter", 3000);
      expect(orResult.ready).toBe(false);
      expect(orResult.waitMs).toBeGreaterThan(0);

      Date.now = originalNow;
    });
  });

  describe("markCall", () => {
    it("records the call time so subsequent canCall respects delay", () => {
      const result1 = ProviderRateLimiter.canCall("openrouter", 3000);
      expect(result1.ready).toBe(true);

      ProviderRateLimiter.markCall("openrouter");

      const result2 = ProviderRateLimiter.canCall("openrouter", 3000);
      expect(result2.ready).toBe(false); // Too soon
    });
  });

  describe("reset", () => {
    it("clears the last call time so canCall returns ready immediately", () => {
      ProviderRateLimiter.markCall("openrouter");

      // Verify not ready
      const before = ProviderRateLimiter.canCall("openrouter", 3000);
      expect(before.ready).toBe(false);

      // Reset
      ProviderRateLimiter.reset("openrouter");

      // Should be ready now
      const after = ProviderRateLimiter.canCall("openrouter", 3000);
      expect(after.ready).toBe(true);
      expect(after.waitMs).toBe(0);
    });

    it("reset on an untracked provider is a no-op (no throw)", () => {
      expect(() => ProviderRateLimiter.reset("nonexistent")).not.toThrow();
    });
  });

  describe("getStatus", () => {
    it("returns empty object when no providers tracked", () => {
      const status = ProviderRateLimiter.getStatus();
      expect(status).toEqual({});
    });

    it("returns tracked providers with lastCallTime", () => {
      const originalNow = Date.now;
      const baseTime = originalNow();
      Date.now = mock(() => baseTime);

      ProviderRateLimiter.markCall("openrouter");

      Date.now = originalNow;

      const status = ProviderRateLimiter.getStatus();
      expect(status).toHaveProperty("openrouter");
      expect(status.openrouter.lastCallTime).toBeGreaterThan(0);
      expect(status.openrouter.nextAvailableTime).toBe(status.openrouter.lastCallTime);
    });

    it("shows multiple providers independently", () => {
      ProviderRateLimiter.markCall("openrouter");
      ProviderRateLimiter.markCall("gemini");

      const status = ProviderRateLimiter.getStatus();
      const providers = Object.keys(status);
      expect(providers).toContain("openrouter");
      expect(providers).toContain("gemini");
    });
  });
});
