#!/usr/bin/env bun
/**
 * src/test.ts — Preflight test for LiteRouter.
 * Checks all configured upstream API keys across all providers.
 */

import { getConfig, isGeminiProvider } from "./config.js";

// ─── ANSI Colors ──────────────────────────────────────────────────────────────
const R = "\x1b[0m";
const bold = "\x1b[1m";
const dim = "\x1b[2m";
const green = "\x1b[32m";
const red = "\x1b[31m";
const yellow = "\x1b[33m";
const cyan = "\x1b[36m";

interface TestResult {
  provider: string;
  key: string;
  status: string;
  error?: string;
  latencyMs: number;
}

export async function runPreflightTest(logProgress = true) {
  const config = getConfig();

  if (logProgress) {
    console.log(`\n${cyan}${bold}  LITEROUTER PREFLIGHT TEST${R}\n`);
    console.log(`  ${dim}Providers :${R} ${Object.keys(config.providers).join(", ")}`);
  }

  let healthy = 0;
  let failed = 0;
  const testResults: TestResult[] = [];

  for (const [providerName, provider] of Object.entries(config.providers)) {
    if (logProgress) {
      console.log(`\n  ${bold}${providerName}${R} ${dim}(${provider.baseUrl})${R}`);
    }

    if (provider.apiKeys.length === 0) {
      if (logProgress) console.log(`    ${red}✗${R} No API keys configured.`);
      continue;
    }

    const modelConfig = config.modelParams[providerName];
    const useGemini = isGeminiProvider(provider);

    for (let i = 0; i < provider.apiKeys.length; i++) {
      const key = provider.apiKeys[i];
      const keyDisplay = `Key ${i + 1} (${key.slice(0, 8)}...)`;

      if (logProgress) process.stdout.write(`    ${dim}Testing ${keyDisplay}...${R}`);

      const start = Date.now();
      try {
        const controller = new AbortController();
        const timeout = setTimeout(() => controller.abort(), 10000);

        let res: Response;

        if (useGemini) {
          const testModel = modelConfig?.model || "gemini-2.5-flash";
          res = await fetch(
            `${provider.baseUrl}/models/${encodeURIComponent(testModel)}:generateContent?key=${encodeURIComponent(key)}`,
            {
              method: "POST",
              headers: { "Content-Type": "application/json" },
              body: JSON.stringify({
                contents: [{ role: "user", parts: [{ text: "hello" }] }],
                generationConfig: { maxOutputTokens: 1 },
              }),
              signal: controller.signal,
            }
          );
        } else {
          const testModel = modelConfig?.model || "gpt-3.5-turbo";
          res = await fetch(`${provider.baseUrl}/chat/completions`, {
            method: "POST",
            headers: {
              "Content-Type": "application/json",
              Authorization: `Bearer ${key}`,
            },
            body: JSON.stringify({
              model: testModel,
              messages: [{ role: "user", content: "hello" }],
              max_tokens: 1,
            }),
            signal: controller.signal,
          });
        }
        clearTimeout(timeout);

        const latencyMs = Date.now() - start;

        if (res.ok) {
          healthy++;
          testResults.push({ provider: providerName, key: keyDisplay, status: "healthy", latencyMs });
          if (logProgress) console.log(`\r    ${green}✓${R} ${bold}${keyDisplay}${R} ${green}healthy${R} ${dim}${latencyMs}ms${R}`);
        } else if (res.status === 429) {
          healthy++; // 429 means key is valid but rate limited
          testResults.push({ provider: providerName, key: keyDisplay, status: "rate-limited", latencyMs });
          if (logProgress) console.log(`\r    ${yellow}⚡${R} ${bold}${keyDisplay}${R} ${yellow}valid (rate limited)${R} ${dim}${latencyMs}ms${R}`);
        } else {
          failed++;
          const errorText = await res.text();
          testResults.push({ provider: providerName, key: keyDisplay, status: "error", error: `HTTP ${res.status}`, latencyMs });
          if (logProgress) console.log(`\r    ${red}✗${R} ${bold}${keyDisplay}${R} ${red}HTTP ${res.status}${R} ${dim}${latencyMs}ms${R} - ${errorText.slice(0, 100)}`);
        }
      } catch (err) {
        failed++;
        const latencyMs = Date.now() - start;
        const errMsg = err instanceof Error ? err.message : String(err);
        testResults.push({ provider: providerName, key: keyDisplay, status: "error", error: errMsg, latencyMs });
        if (logProgress) console.log(`\r    ${red}✗${R} ${bold}${keyDisplay}${R} ${red}${errMsg}${R} ${dim}${latencyMs}ms${R}`);
      }
    }
  }

  const totalKeys = Object.values(config.providers).reduce((sum, p) => sum + p.apiKeys.length, 0);

  if (logProgress) {
    console.log(`\n${cyan}${"─".repeat(50)}${R}`);
    console.log(`  ${bold}${healthy}/${totalKeys}${R} keys healthy.${failed > 0 ? ` ${red}${failed} failed.${R}` : ""}`);
    console.log(`${cyan}${"─".repeat(50)}${R}\n`);
  }

  return { healthy, failed, testResults };
}

// If run directly
if (import.meta.main) {
  runPreflightTest().catch(console.error);
}
