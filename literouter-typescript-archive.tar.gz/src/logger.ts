/**
 * src/logger.ts
 *
 * Simple logger that writes to console and appends to an error.log file
 * for critical events like key quarantines and upstream failures.
 */

import { appendFileSync, existsSync, writeFileSync } from "fs";
import { join } from "path";

const ERROR_LOG = join(process.cwd(), "error.log");
const SERVER_LOG = join(process.cwd(), "server.log");

// Ensure log files exist
if (!existsSync(ERROR_LOG)) {
  writeFileSync(ERROR_LOG, `--- LiteRouter Error Log Started: ${new Date().toISOString()} ---\n`);
}
if (!existsSync(SERVER_LOG)) {
  writeFileSync(SERVER_LOG, `--- LiteRouter Server Log Started: ${new Date().toISOString()} ---\n`);
}

function formatMsg(level: string, msg: string) {
  const ts = new Date().toISOString();
  return `[${ts}] [${level}] ${msg}\n`;
}

export const logger = {
  info: (msg: string) => {
    const formatted = formatMsg("INFO", msg);
    console.log(`[INFO] ${msg}`);
    appendFileSync(SERVER_LOG, formatted);
  },
  
  warn: (msg: string) => {
    const formatted = formatMsg("WARN", msg);
    console.warn(`\x1b[33m[WARN] ${msg}\x1b[0m`);
    appendFileSync(ERROR_LOG, formatted);
    appendFileSync(SERVER_LOG, formatted);
  },
  
  error: (msg: string, err?: any) => {
    const errorMsg = err ? `${msg} | Error: ${err.message || String(err)}` : msg;
    const formatted = formatMsg("ERROR", errorMsg);
    console.error(`\x1b[31m[ERROR] ${errorMsg}\x1b[0m`);
    appendFileSync(ERROR_LOG, formatted);
    appendFileSync(SERVER_LOG, formatted);
  }
};
