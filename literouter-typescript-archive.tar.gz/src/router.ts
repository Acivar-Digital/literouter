/**
 * src/router.ts
 *
 * Per-provider round-robin API key router.
 * Each provider has its own counter, cooldowns, and quarantine list.
 */

import { getConfig } from "./config.js";
import { logger } from "./logger.js";
import { ProviderRateLimiter } from "./rate_limiter.js";
import { loadRouterState, saveRouterState } from "./storage.js";

interface ProviderState {
  counter: number;
  deadKeys: Set<string>;
  cooldowns: Map<string, number>;
}

const providerStates = new Map<string, ProviderState>();

// Load persistent state on initialization
const savedState = loadRouterState();

function getProviderState(providerName: string): ProviderState {
  let state = providerStates.get(providerName);
  if (!state) {
    state = {
      counter: savedState.counters[providerName] ?? 0,
      deadKeys: new Set(),
      cooldowns: new Map(),
    };
    providerStates.set(providerName, state);
  }
  return state;
}

/**
 * Returns the next available API key for a given provider.
 * Deterministic: tries keys in order starting from the current counter.
 */
export function getNextKey(providerName: string): string | null {
  const { providers } = getConfig();
  const provider = providers[providerName];
  if (!provider) return null;

  const state = getProviderState(providerName);
  const alive = provider.apiKeys.filter((k) => !state.deadKeys.has(k));

  if (alive.length === 0) return null;

  const now = Date.now();
  const start = state.counter % alive.length;

  for (let i = 0; i < alive.length; i++) {
    const idx = (start + i) % alive.length;
    const key = alive[idx];
    const coolUntil = state.cooldowns.get(key) ?? 0;

    if (now >= coolUntil) {
      state.counter = (start + i + 1) % alive.length;
      persistCounters();
      return key;
    }
  }

  return null; // All alive keys are on cooldown
}

/**
 * Persist all provider counters to disk.
 */
function persistCounters(): void {
  const counters: Record<string, number> = {};
  for (const [name, state] of providerStates.entries()) {
    counters[name] = state.counter;
  }
  saveRouterState({ counters, lastUpdated: Date.now() });
}

/**
 * Handles provider errors by updating the state of the key.
 * 429 -> Exponential backoff cooldown (1m → 2m → 4m → ... → 1h max)
 * 401, 403 -> Quarantine permanently
 */
export function reportError(providerName: string, key: string, status: number) {
  const state = getProviderState(providerName);

  if (status === 429) {
    const existingCooldown = state.cooldowns.get(key) ?? 0;
    const baseDelay = 60_000; // 1 minute
    let delay = baseDelay;

    if (existingCooldown > Date.now()) {
      // Still cooling down — double the remaining time for exponential backoff
      const remainingMs = existingCooldown - Date.now();
      delay = Math.min(remainingMs * 2, 3_600_000); // Max 1 hour
    }

    state.cooldowns.set(key, Date.now() + delay);
    logger.info(`[${providerName}] 429 for key ${key.slice(0, 10)}... | ${Math.ceil(delay / 1000)}s cooldown`);
  } else if (status === 401 || status === 403) {
    state.deadKeys.add(key);
    logger.warn(`[${providerName}] ${status} for key ${key.slice(0, 10)}... | Quarantined permanently`);
  }
}

/**
 * Returns current status of the router per provider.
 */
export function getRouterStatus() {
  const { providers } = getConfig();
  const now = Date.now();
  const status: Record<string, any> = {};

  for (const providerName of Object.keys(providers)) {
    const state = getProviderState(providerName);
    const activeCooldowns = Array.from(state.cooldowns.entries())
      .filter(([_, until]) => until > now)
      .map(([key, until]) => ({
        key: `${key.slice(0, 10)}...`,
        remainingSec: Math.ceil((until - now) / 1000),
      }));

    status[providerName] = {
      totalKeys: providers[providerName].apiKeys.length,
      deadKeysCount: state.deadKeys.size,
      quarantinedKeys: Array.from(state.deadKeys).map((k) => `${k.slice(0, 10)}...`),
      activeCooldowns,
      counterPosition: state.counter,
    };
  }

  status.rateLimiter = ProviderRateLimiter.getStatus();

  return status;
}
