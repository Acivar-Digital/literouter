/**
 * src/config.ts
 *
 * JSON-based configuration for LiteRouter.
 * Provider-centric: each provider has baseUrl + apiKeys,
 * and a companion <provider>_model section with model params.
 */

import { readFileSync, existsSync } from "fs";
import { join } from "path";

export interface ProviderConfig {
  baseUrl: string;
  apiKeys: string[];
  models?: Record<string, ModelParams>;
  minDelayMs?: number;
}

export interface ModelParams {
  model: string;
  [key: string]: any; // temperature, reasoning, reason_effort, etc.
}

export interface RouterConfig {
  // Server
  port: number;
  host: string;
  authKey: string | null;

  // Providers keyed by name (e.g. 'openrouter', 'opencode')
  providers: Record<string, ProviderConfig>;

  // Model params keyed by provider name
  modelParams: Record<string, ModelParams>;

  // Delay between sequential requests (ms) for key rotation pacing
  rotateDelayMs: number;

  // Per-provider minimum delay between calls (ms)
  providerMinDelays: Record<string, number>;
}

const CONFIG_PATH = join(process.cwd(), "config.json");
let cachedConfig: RouterConfig | null = null;

export function getConfig(): RouterConfig {
  if (cachedConfig) return cachedConfig;

  if (!existsSync(CONFIG_PATH)) {
    throw new Error(
      `[Config] Error: config.json not found at ${CONFIG_PATH}. ` +
      `Please create it using config.example.json as a template.`
    );
  }

  try {
    const raw = readFileSync(CONFIG_PATH, "utf-8");
    const json = JSON.parse(raw);

    const server = json.server || {};
    const providers: Record<string, ProviderConfig> = {};
    const modelParams: Record<string, ModelParams> = {};

    // Parse all top-level keys that are NOT 'server' and NOT '*_model'
    for (const [key, val] of Object.entries(json)) {
      if (key === "server") continue;
      if (key.endsWith("_model")) continue;
      if (!val || typeof val !== "object") continue;

      const v = val as Record<string, any>;

      // Must have baseUrl and apiKeys to be a provider
      if (typeof v.baseUrl !== "string" || !Array.isArray(v.apiKeys)) continue;

      const baseUrl = v.baseUrl.replace(/\/$/, "");
      const apiKeys = v.apiKeys.map(String);

      if (!baseUrl) console.warn(`[Config] Warning: ${key}.baseUrl is not set.`);
      if (apiKeys.length === 0) console.warn(`[Config] Warning: ${key}.apiKeys is empty.`);

      providers[key] = { baseUrl, apiKeys };

      // ─── Extract minDelayMs if present ─────────────────────────────
      if (typeof v.minDelayMs === "number") {
        providers[key].minDelayMs = v.minDelayMs;
      }
    }

    // Parse nested "models" blocks inside each provider
    for (const [key, val] of Object.entries(json)) {
      if (key === "server") continue;
      if (!val || typeof val !== "object") continue;
      const v = val as Record<string, any>;
      if (!v.models || typeof v.models !== "object") continue;

      for (const [alias, m] of Object.entries(v.models)) {
        const mp = m as Record<string, any>;
        if (!mp.model) {
          console.warn(`[Config] Warning: ${key}.models.${alias} is missing 'model' field.`);
          continue;
        }
        const params: ModelParams = { model: String(mp.model) };
        for (const [pk, pv] of Object.entries(mp)) {
          if (pk === "model") continue;
          if (typeof pv === "string" && !isNaN(Number(pv)) && pv.trim() !== "") {
            params[pk] = Number(pv);
          } else {
            params[pk] = pv;
          }
        }
        modelParams[`${key}/${alias}`] = params;
      }
    }

    // Parse companion *_model sections (legacy top-level format, fallback)
    for (const [key, val] of Object.entries(json)) {
      if (!key.endsWith("_model")) continue;
      if (!val || typeof val !== "object") continue;

      const providerName = key.replace(/_model$/, "");
      const v = val as Record<string, any>;

      if (!v.model) {
        console.warn(`[Config] Warning: ${key} is missing 'model' field.`);
        continue;
      }

      const params: ModelParams = { model: String(v.model) };
      for (const [pk, pv] of Object.entries(v)) {
        if (pk === "model") continue;
        if (typeof pv === "string" && !isNaN(Number(pv)) && pv.trim() !== "") {
          params[pk] = Number(pv);
        } else {
          params[pk] = pv;
        }
      }

      if (!modelParams[providerName]) {
        modelParams[providerName] = params;
      }
    }

    if (Object.keys(providers).length === 0) {
      console.warn("[Config] Warning: No providers defined!");
    }

    // ─── Build per-provider minDelays (fallback to rotateDelayMs) ─────
    const providerMinDelays: Record<string, number> = {};
    for (const [name, p] of Object.entries(providers)) {
      const fallbackDelay = typeof server.rotateDelayMs === "number"
        ? server.rotateDelayMs
        : 2000;
      providerMinDelays[name] = p.minDelayMs ?? fallbackDelay;
    }

    cachedConfig = {
      port: typeof server.port === "number" ? server.port : parseInt(server.port || "7766", 10),
      host: server.host || "0.0.0.0",
      authKey: server.authKey || null,
      providers,
      modelParams,
      rotateDelayMs: typeof server.rotateDelayMs === "number" ? server.rotateDelayMs : 2000,
      providerMinDelays,
    };

    return cachedConfig;
  } catch (error) {
    if (error instanceof Error && error.message.startsWith("[Config]")) {
      throw error;
    }
    throw new Error(`[Config] Failed to parse config.json: ${error}`);
  }
}

/**
 * Check if a provider uses the Gemini API (based on its baseUrl).
 */
export function isGeminiProvider(provider: ProviderConfig): boolean {
  return provider.baseUrl.includes("generativelanguage.googleapis.com");
}
