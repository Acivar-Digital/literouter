/**
 * src/metrics.ts
 *
 * Simple metrics collection for LiteRouter.
 * Tracks request counts, error rates, and latency.
 */

interface Metrics {
    requestsTotal: number;
    requestsSuccess: number;
    requestsError: number;
    keyUsage: Record<string, number>;
    errorByStatus: Record<number, number>;
    latencySum: number;
    latencyCount: number;
    rateLimitWaits: number;
    rateLimitWaitTotalMs: number;
}

class MetricsCollector {
    private metrics: Metrics;
    private startTime: number;

    constructor() {
        this.metrics = {
            requestsTotal: 0,
            requestsSuccess: 0,
            requestsError: 0,
            keyUsage: {},
            errorByStatus: {},
            latencySum: 0,
            latencyCount: 0,
            rateLimitWaits: 0,
            rateLimitWaitTotalMs: 0,
        };
        this.startTime = Date.now();
    }

    incrementRequest() {
        this.metrics.requestsTotal++;
    }

    incrementSuccess() {
        this.metrics.requestsSuccess++;
    }

    incrementError() {
        this.metrics.requestsError++;
    }

    incrementKeyUsage(key: string) {
        const keyPrefix = key.slice(0, 10) + "...";
        this.metrics.keyUsage[keyPrefix] = (this.metrics.keyUsage[keyPrefix] || 0) + 1;
    }

    incrementErrorByStatus(status: number) {
        this.metrics.errorByStatus[status] = (this.metrics.errorByStatus[status] || 0) + 1;
    }

    addLatency(latencyMs: number) {
        this.metrics.latencySum += latencyMs;
        this.metrics.latencyCount++;
    }

    incrementRateLimitWait() {
        this.metrics.rateLimitWaits++;
    }

    addRateLimitWaitMs(ms: number) {
        this.metrics.rateLimitWaitTotalMs += ms;
    }

    getMetrics() {
        const uptime = Date.now() - this.startTime;
        const avgLatency =
            this.metrics.latencyCount > 0
                ? this.metrics.latencySum / this.metrics.latencyCount
                : 0;

        return {
            ...this.metrics,
            uptimeSeconds: Math.floor(uptime / 1000),
            requestsPerSecond: this.metrics.requestsTotal / (uptime / 1000) || 0,
            errorRate:
                this.metrics.requestsTotal > 0
                    ? this.metrics.requestsError / this.metrics.requestsTotal
                    : 0,
            averageLatencyMs: avgLatency,
        };
    }

    reset() {
        this.metrics = {
            requestsTotal: 0,
            requestsSuccess: 0,
            requestsError: 0,
            keyUsage: {},
            errorByStatus: {},
            latencySum: 0,
            latencyCount: 0,
            rateLimitWaits: 0,
            rateLimitWaitTotalMs: 0,
        };
        this.startTime = Date.now();
    }
}

// Singleton instance
export const metrics = new MetricsCollector();