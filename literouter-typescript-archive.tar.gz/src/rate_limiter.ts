/**
 * src/rate_limiter.ts
 *
 * Provider-level rate limiter for LiteRouter.
 * Tracks last call time per provider and enforces minimum delays between calls.
 * Simple static class with in-memory tracking — no external dependencies.
 */

import { logger } from "./logger.js";

export interface RateLimitStatus {
  ready: boolean;
  waitMs: number;
}

export interface ProviderRateLimitInfo {
  lastCallTime: number | null;
  nextAvailableTime: number | null;
}

/**
 * ProviderRateLimiter — static class for per-provider call pacing.
 *
 * Maintains a Map of providerName → lastCallTimestamp.
 * Used by the request queue to gate outgoing requests and avoid
 * hitting upstream rate limits (e.g. OpenRouter's 20 calls/min).
 */
export class ProviderRateLimiter {
  private static lastCallTimes = new Map<string, number>();

  /**
   * Check whether a call can be made to a provider right now.
   *
   * @param providerName - The provider identifier (e.g. "openrouter")
   * @param minDelayMs   - Minimum required delay between calls in milliseconds
   * @returns { ready: boolean, waitMs: number }
   *   - ready: true if enough time has passed (or first call)
   *   - waitMs: milliseconds to wait before calling (0 if ready)
   */
  static canCall(providerName: string, minDelayMs: number): RateLimitStatus {
    const lastCall = ProviderRateLimiter.lastCallTimes.get(providerName);

    if (lastCall === undefined) {
      return { ready: true, waitMs: 0 };
    }

    const elapsed = Date.now() - lastCall;
    const waitMs = Math.max(0, minDelayMs - elapsed);

    if (waitMs > 0) {
      logger.info(
        `[RateLimiter] ${providerName} must wait ${waitMs}ms ` +
        `(minDelay=${minDelayMs}ms, elapsed=${elapsed}ms)`
      );
      return { ready: false, waitMs };
    }

    return { ready: true, waitMs: 0 };
  }

  /**
   * Record that a call was just made to a provider.
   * Call this AFTER a successful upstream response (or any response
   * that consumed an upstream rate limit slot, including 429s).
   *
   * @param providerName - The provider identifier
   */
  static markCall(providerName: string): void {
    ProviderRateLimiter.lastCallTimes.set(providerName, Date.now());
  }

  /**
   * Reset tracking for a provider (clears last call time).
   * Use on network failures where the upstream call never actually happened,
   * so we can retry immediately without waiting for the rate limit timer.
   *
   * @param providerName - The provider identifier
   */
  static reset(providerName: string): void {
    ProviderRateLimiter.lastCallTimes.delete(providerName);
    logger.info(`[RateLimiter] Reset tracking for ${providerName}`);
  }

  /**
   * Get current rate limiter status for all tracked providers.
   * Used by the /health endpoint.
   *
   * @returns Record mapping provider name to lastCallTime + nextAvailableTime (null if never called)
   */
  static getStatus(): Record<string, ProviderRateLimitInfo> {
    const status: Record<string, ProviderRateLimitInfo> = {};
    for (const [provider, lastCallTime] of ProviderRateLimiter.lastCallTimes.entries()) {
      status[provider] = {
        lastCallTime,
        nextAvailableTime: lastCallTime, // caller must add minDelayMs to interpret
      };
    }
    return status;
  }
}
