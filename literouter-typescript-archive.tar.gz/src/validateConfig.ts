/**
 * src/validateConfig.ts
 *
 * Utility to validate config.json.
 * Can be executed via `bun run src/validateConfig.ts`.
 */

import { existsSync, readFileSync } from 'fs';
import { join } from 'path';

/**
 * Validate config.json.
 * Exits with code 0 on success, 1 on failure.
 */
function validateConfig(): void {
  const configPath = join(process.cwd(), 'config.json');

  if (!existsSync(configPath)) {
    console.error(`[Config] Error: config.json not found at ${configPath}.`);
    process.exit(1);
  }

  const raw = readFileSync(configPath, 'utf-8');
  let parsed: any;
  try {
    parsed = JSON.parse(raw);
  } catch (e) {
    console.error('[Config] Error: Failed to parse config.json as JSON.', e);
    process.exit(1);
  }

  // Validate server object
  const server = parsed.server;
  if (!server || typeof server !== 'object') {
    console.error('[Config] Error: missing "server" section.');
    process.exit(1);
  }
  if (server.host !== undefined && typeof server.host !== 'string') {
    console.error('[Config] Error: server.host must be a string.');
    process.exit(1);
  }
  if (server.port !== undefined && typeof server.port !== 'number') {
    console.error('[Config] Error: server.port must be a number.');
    process.exit(1);
  }

  // Find and validate providers (any top-level key with baseUrl + apiKeys, excluding 'server' and '*_model')
  let providerCount = 0;

  for (const [key, val] of Object.entries(parsed)) {
    if (key === 'server') continue;
    if (key.endsWith('_model')) continue;
    if (!val || typeof val !== 'object') continue;

    const v = val as Record<string, any>;

    // Check if it looks like a provider
    if (!v.baseUrl && !v.apiKeys) continue;

    if (typeof v.baseUrl !== 'string') {
      console.error(`[Config] Error: ${key}.baseUrl must be a string.`);
      process.exit(1);
    }
    if (!Array.isArray(v.apiKeys) || v.apiKeys.length === 0) {
      console.error(`[Config] Error: ${key}.apiKeys must be a non-empty array of strings.`);
      process.exit(1);
    }
    if (!v.apiKeys.every((k: unknown) => typeof k === 'string')) {
      console.error(`[Config] Error: ${key}.apiKeys must contain only strings.`);
      process.exit(1);
    }

    providerCount++;

    // Check for model configuration (modern "models" block or legacy "*_model" section)
    const hasModelsBlock = v.models && typeof v.models === 'object' && Object.keys(v.models).length > 0;
    const modelKey = `${key}_model`;
    const modelVal = parsed[modelKey];
    const hasLegacyModel = modelVal && typeof modelVal === 'object';

    if (!hasModelsBlock && !hasLegacyModel) {
      console.warn(`[Config] Warning: No model configuration for provider '${key}'. Add a "models" block or ${modelKey} section.`);
    }

    // Validate modern models block if present
    if (hasModelsBlock) {
      for (const [alias, m] of Object.entries(v.models)) {
        const mp = m as Record<string, any>;
        if (!mp.model || typeof mp.model !== 'string') {
          console.error(`[Config] Error: ${key}.models.${alias}.model must be a string.`);
          process.exit(1);
        }
      }
    }

    // Validate legacy *_model section if present
    if (hasLegacyModel) {
      if (typeof modelVal.model !== 'string') {
        console.error(`[Config] Error: ${modelKey}.model must be a string.`);
        process.exit(1);
      }
    }
  }

  if (providerCount === 0) {
    console.error('[Config] Error: No providers found. Add at least one provider with baseUrl and apiKeys.');
    process.exit(1);
  }

  console.log(`✅ Config validation passed. (${providerCount} provider(s))`);
  process.exit(0);
}

if (import.meta.url === `file://${process.argv[1]}`) {
  validateConfig();
}