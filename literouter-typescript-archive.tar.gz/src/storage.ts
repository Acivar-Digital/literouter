/**
 * src/storage.ts
 *
 * Persistent storage for per-provider router state.
 * Stores counters per provider in data/router-state.json.
 */

import { existsSync, readFileSync, writeFileSync, mkdirSync } from "fs";
import { join, dirname } from "path";

const STORAGE_PATH = join(process.cwd(), "data", "router-state.json");

export interface RouterState {
    counters: Record<string, number>;
    lastUpdated: number;
}

/**
 * Load router state from persistent storage.
 * Returns default state if file doesn't exist or is corrupted.
 * Handles legacy single-counter format gracefully.
 */
export function loadRouterState(): RouterState {
    try {
        if (!existsSync(STORAGE_PATH)) {
            return { counters: {}, lastUpdated: Date.now() };
        }

        const data = readFileSync(STORAGE_PATH, "utf-8");
        const parsed = JSON.parse(data);

        // Handle legacy format (single counter)
        if (typeof parsed.counter === "number" && !parsed.counters) {
            return {
                counters: { _legacy: parsed.counter },
                lastUpdated: parsed.lastUpdated ?? Date.now(),
            };
        }

        if (
            parsed.counters &&
            typeof parsed.counters === "object" &&
            typeof parsed.lastUpdated === "number"
        ) {
            return parsed;
        }

        console.warn("[Storage] Invalid state format, using default");
        return { counters: {}, lastUpdated: Date.now() };
    } catch (error) {
        console.warn("[Storage] Failed to load state, using default:", error);
        return { counters: {}, lastUpdated: Date.now() };
    }
}

/**
 * Save router state to persistent storage.
 */
export function saveRouterState(state: RouterState): void {
    try {
        const dir = dirname(STORAGE_PATH);
        if (!existsSync(dir)) {
            mkdirSync(dir, { recursive: true });
        }

        const data = JSON.stringify(
            {
                ...state,
                lastUpdated: Date.now(),
            },
            null,
            2
        );
        writeFileSync(STORAGE_PATH, data, "utf-8");
    } catch (error) {
        console.error("[Storage] Failed to save state:", error);
    }
}