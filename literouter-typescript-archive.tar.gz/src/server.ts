#!/usr/bin/env bun
/**
 * src/server.ts
 *
 * OpenAI-compatible HTTP server for LiteRouter.
 * Routes requests to the correct provider based on the model field.
 *
 * Client sends model="openrouter" → LiteRouter resolves actual model + params
 * from config, picks a key via round-robin, forwards to the provider's baseUrl.
 */

import { getConfig, isGeminiProvider } from "./config.js";
import { ProviderRateLimiter } from "./rate_limiter.js";
import { getNextKey, getRouterStatus, reportError } from "./router.js";
import { logger } from "./logger.js";
import { metrics } from "./metrics.js";

const config = getConfig();

// ─── Request Queue (sequential processing) ──────────────────────────────────
const DEFAULT_FALLBACK_DELAY_MS = config.rotateDelayMs ?? 2000; // fallback delay when provider has no minDelayMs

interface QueuedRequest {
  req: Request;
  resolve: (response: Response) => void;
  enqueueTime: number;
  providerName?: string;
  body?: any;
}

const requestQueue: QueuedRequest[] = [];
let isProcessing = false;

async function processQueue() {
  if (isProcessing || requestQueue.length === 0) return;
  isProcessing = true;

  const queued = requestQueue.shift()!;

  try {
    const response = await handleChat(queued.req);
    queued.resolve(response);
  } catch (err: any) {
    queued.resolve(
      Response.json(
        { error: { message: `Internal server error: ${err?.message || String(err)}`, type: "internal_error" } },
        { status: 500 }
      )
    );
  }

  isProcessing = false;

  // ─── Process next immediately (rate limiter handles pacing) ────
  if (requestQueue.length > 0) {
    processQueue();
  }
}

function enqueueRequest(req: Request): Promise<Response> {
  return new Promise((resolve) => {
    requestQueue.push({ req, resolve, enqueueTime: Date.now() });
    logger.info(`[Queue] Request queued (position: ${requestQueue.length})`);
    processQueue();
  });
}

function checkAuth(req: Request): boolean {
  if (!config.authKey) return true;
  const auth = req.headers.get("Authorization") ?? "";
  const token = auth.startsWith("Bearer ") ? auth.slice(7).trim() : "";
  return token === config.authKey;
}

function buildGeminiRequestBody(body: any): Record<string, any> {
  const requestBody: Record<string, any> = {};
  const contents: Array<Record<string, any>> = [];
  const systemParts: string[] = [];
  const generationConfig: Record<string, any> = {};

  const pushContent = (role: string, text: string) => {
    contents.push({
      role,
      parts: [{ text }],
    });
  };

  const pushMessage = (message: any) => {
    const text = typeof message.content === "string"
      ? message.content
      : JSON.stringify(message.content);

    if (message.role === "system") {
      systemParts.push(text);
    } else if (message.role === "assistant") {
      pushContent("model", text);
    } else {
      pushContent("user", text);
    }
  };

  if (Array.isArray(body.messages)) {
    body.messages.forEach(pushMessage);
  }

  if (typeof body.prompt === "string") {
    pushContent("user", body.prompt);
  } else if (body.prompt && typeof body.prompt === "object") {
    if (typeof body.prompt.context === "string") {
      systemParts.push(body.prompt.context);
    }
    if (Array.isArray(body.prompt.messages)) {
      body.prompt.messages.forEach(pushMessage);
    }
  }

  if (contents.length > 0) {
    requestBody.contents = contents;
  }

  if (systemParts.length > 0) {
    requestBody.systemInstruction = {
      parts: [{ text: systemParts.join("\n\n") }],
    };
  }

  if (typeof body.temperature === "number") generationConfig.temperature = body.temperature;
  if (typeof body.top_p === "number") generationConfig.topP = body.top_p;
  if (typeof body.top_k === "number") generationConfig.topK = body.top_k;
  if (typeof body.n === "number") generationConfig.candidateCount = body.n;
  if (typeof body.max_tokens === "number") generationConfig.maxOutputTokens = body.max_tokens;
  if (body.stop !== undefined) {
    generationConfig.stopSequences = Array.isArray(body.stop)
      ? body.stop
      : [String(body.stop)];
  }

  if (Object.keys(generationConfig).length > 0) {
    requestBody.generationConfig = generationConfig;
  }

  return requestBody;
}

function transformGeminiResponse(geminiResponse: any): any {
  const openaiResponse: any = {
    id: geminiResponse.responseId || `chatcmpl-${Date.now()}`,
    object: "chat.completion",
    created: Math.floor(Date.now() / 1000),
    model: geminiResponse.modelVersion || "gemini",
    choices: [],
    usage: {
      prompt_tokens: geminiResponse.usageMetadata?.promptTokenCount || 0,
      completion_tokens: geminiResponse.usageMetadata?.candidatesTokenCount || 0,
      total_tokens: geminiResponse.usageMetadata?.totalTokenCount || 0,
    },
  };

  if (geminiResponse.candidates && geminiResponse.candidates.length > 0) {
    const candidate = geminiResponse.candidates[0];
    const content = candidate.content?.parts?.map((part: any) => part.text).join("") || "";

    openaiResponse.choices.push({
      index: candidate.index || 0,
      message: {
        role: "assistant",
        content: content,
      },
      finish_reason: candidate.finishReason?.toLowerCase() || "stop",
    });
  }

  return openaiResponse;
}

/**
 * Forwards a request to the resolved provider with a round-robin key.
 * Handles both streaming and non-streaming responses.
 */
async function handleChat(req: Request): Promise<Response> {
  if (!checkAuth(req)) {
    return Response.json(
      { error: { message: "Invalid API key", type: "invalid_request_error" } },
      { status: 401 }
    );
  }

  let body: any;
  try {
    body = await req.json();
  } catch (err) {
    return Response.json(
      { error: { message: "Invalid JSON body", type: "invalid_request_error" } },
      { status: 400 }
    );
  }

  // Resolve provider: client sends "provider/model-alias" or just "provider"
  const rawModel: string = body.model;
  let providerName: string;
  let modelAlias: string | null = null;

  if (rawModel && rawModel.includes("/")) {
    const parts = rawModel.split("/", 2);
    providerName = parts[0];
    modelAlias = parts[1];
  } else {
    providerName = rawModel;
    // Auto-resolve to the first available model for this provider
    const providerModels = Object.keys(config.modelParams)
      .filter(k => k.startsWith(providerName + "/"));
    if (providerModels.length > 0) {
      modelAlias = providerModels[0].split("/")[1];
    }
  }
  if (!providerName || !config.providers[providerName]) {
    const available = Object.keys(config.providers).join(", ");
    const modelKeys = Object.keys(config.modelParams).filter(k => k.startsWith(providerName + "/")).join(", ");
    const hint = modelKeys ? ` (models: ${modelKeys})` : "";
    return Response.json(
      { error: { message: `Unknown provider '${providerName}'. Available: ${available}${hint}`, type: "invalid_request_error" } },
      { status: 400 }
    );
  }

  const provider = config.providers[providerName];
  const useGemini = isGeminiProvider(provider);

  // Get next key via round-robin for this provider
  const key = getNextKey(providerName);
  if (!key) {
    return Response.json(
      { error: `[${providerName}] No available API keys. All keys might be on cooldown or quarantined.` },
      { status: 503 }
    );
  }

  // ─── Rate limit check ─────────────────────────────────────────────
  const minDelayMs = config.providerMinDelays[providerName] ?? DEFAULT_FALLBACK_DELAY_MS;
  const rateLimit = ProviderRateLimiter.canCall(providerName, minDelayMs);
  if (!rateLimit.ready) {
    logger.info(`[RateLimiter] ${providerName} waiting ${rateLimit.waitMs}ms`);
    metrics.incrementRateLimitWait();
    metrics.addRateLimitWaitMs(rateLimit.waitMs);
    await new Promise(r => setTimeout(r, rateLimit.waitMs));
  }

  // Track request metrics
  metrics.incrementRequest();
  metrics.incrementKeyUsage(key);
  const startTime = Date.now();

// Apply model params from config (actual model name + provider-specific settings)
  // Look up by "provider/alias" first, then fall back to just "provider"
  const lookupKey = modelAlias ? `${providerName}/${modelAlias}` : providerName;
  const modelConfig = config.modelParams[lookupKey] ?? config.modelParams[providerName];
  if (modelConfig) {
    // Set the actual model name
    body.model = modelConfig.model;

    // Apply all other params (temperature, reasoning, reason_effort, etc.)
    for (const [k, v] of Object.entries(modelConfig)) {
      if (k === "model") continue;
      body[k] = v;
    }
  }

  // Disable streaming entirely — force non-streaming responses
  body.stream = false;

  logger.info(
    `[▶️ Sending] ${providerName} | model=${body.model} | key=${key.slice(0, 10)}...`
  );

  let targetUrl = `${provider.baseUrl}/chat/completions`;
  let bodyStr = JSON.stringify(body);

  if (process.env.DEBUG) {
    console.log(`[DEBUG] Body: ${bodyStr}`);
  }
  const headers: Record<string, string> = {
    Authorization: `Bearer ${key}`,
    "Content-Type": "application/json",
  };

  if (useGemini) {
    targetUrl = `${provider.baseUrl}/models/${encodeURIComponent(body.model)}:generateContent?key=${encodeURIComponent(key)}`;
    const googleBody = buildGeminiRequestBody(body);
    bodyStr = JSON.stringify(googleBody);
    delete headers.Authorization;
  }

  const controller = new AbortController();
  const timeoutId = setTimeout(() => controller.abort(), 60000); // 60 seconds

  const options: RequestInit = {
    method: "POST",
    headers,
    body: bodyStr,
    signal: controller.signal,
  };

  try {
    const upstream = await fetch(targetUrl, options);
    clearTimeout(timeoutId);
    ProviderRateLimiter.markCall(providerName);

    if (upstream.status === 429 || upstream.status === 401 || upstream.status === 403) {
      reportError(providerName, key, upstream.status);
    }

    if (!upstream.ok) {
      let errMsg = `Upstream ${upstream.status}`;
      try {
        const errText = await upstream.text();
        errMsg = errText;
      } catch { /* ignore */ }

      console.log(`[⚠️ Error] ${providerName} returned ${upstream.status}: ${errMsg.slice(0, 200)}`);

      // Track error metrics
      metrics.incrementError();
      metrics.incrementErrorByStatus(upstream.status);

      return Response.json(
        { error: { message: errMsg, type: "upstream_error", code: upstream.status } },
        { status: upstream.status }
      );
    }

    // Track success metrics
    metrics.incrementSuccess();
    const latency = Date.now() - startTime;
    metrics.addLatency(latency);

    logger.info(`[✅ Success] ${providerName} | status=${upstream.status} | latency=${latency}ms`);

    // Non-streaming response (streaming is forced off)
    const responseText = await upstream.text();
    let responseData = JSON.parse(responseText);

    if (useGemini) {
      responseData = transformGeminiResponse(responseData);
    }

    return Response.json(responseData);
  } catch (err) {
    logger.error(`Error fetching from ${targetUrl}`, err);
    return Response.json(
      { error: { message: "Upstream error or network issue.", type: "upstream_error" } },
      { status: 502 }
    );
  }
}

/**
 * Status endpoint showing per-provider router state.
 */
function handleHealth(): Response {
  return Response.json({
    status: "ok",
    timestamp: new Date().toISOString(),
    config: {
      port: config.port,
      host: config.host,
      authEnabled: !!config.authKey,
      providers: Object.fromEntries(
        Object.entries(config.providers).map(([name, p]) => [
          name,
          {
            baseUrl: p.baseUrl,
            keys: p.apiKeys.length,
            model: config.modelParams[name]?.model ?? "not configured",
            minDelayMs: config.providerMinDelays[name] ?? DEFAULT_FALLBACK_DELAY_MS,
          },
        ])
      ),
    },
    router: getRouterStatus(),
    queue: {
      length: requestQueue.length,
      isProcessing,
      rotateDelayMs: DEFAULT_FALLBACK_DELAY_MS,
    },
    rateLimiter: {
      providerStatus: ProviderRateLimiter.getStatus(),
      defaultMinDelayMs: DEFAULT_FALLBACK_DELAY_MS,
    },
    metrics: metrics.getMetrics(),
  });
}

const server = Bun.serve({
  port: config.port,
  hostname: config.host,
  idleTimeout: 200,
  async fetch(req) {
    const url = new URL(req.url);

    if (req.method === "POST" && url.pathname === "/v1/chat/completions") {
      return enqueueRequest(req);
    }

    if (req.method === "GET" && (url.pathname === "/health" || url.pathname === "/")) {
      return handleHealth();
    }

    return Response.json({ error: "Not found" }, { status: 404 });
  },
});

const providerNames = Object.keys(config.providers).join(", ");
let startupMsg = `\n${"=".repeat(60)}\n`;
startupMsg += `🚀 LiteRouter is listening on http://${config.host}:${config.port}\n`;
startupMsg += `${"-".repeat(60)}\n`;
startupMsg += `[Config] Providers Loaded: ${providerNames}\n`;
for (const [name, provider] of Object.entries(config.providers)) {
  const model = config.modelParams[name]?.model ?? "no model configured";
  startupMsg += `  └─ ${name}: ${provider.baseUrl} \n     → ${model} (${provider.apiKeys.length} keys)\n`;
}
startupMsg += `[Config] Auth: ${config.authKey ? "Enabled" : "Disabled"}\n`;
startupMsg += `${"=".repeat(60)}\n`;
startupMsg += `\n☁️  Waiting for requests...\n`;

logger.info(startupMsg);

process.on("SIGINT", () => {
  server.stop();
  process.exit(0);
});
