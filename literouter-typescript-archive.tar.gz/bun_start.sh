#!/bin/bash
# bun_start.sh — start liteRouter in a tmux session (idempotent)
# If a session named 'literouter' already exists, do nothing.

set -euo pipefail

SESSION="literouter"
PROJECT_DIR="$(cd "$(dirname "$0")" && pwd)"

# Kill any leftover detached session with the same name
tmux kill-session -t "$SESSION" 2>/dev/null || true
sleep 0.3

# Start fresh detached session
tmux new-session -d -s "$SESSION" -c "$PROJECT_DIR" 'bun start'
echo "🚀 liteRouter started in tmux session '$SESSION'"
echo "   Attach:  tmux attach -t $SESSION"
echo "   Stop:    tmux send-keys -t $SESSION C-c"
echo "   Kill:    tmux kill-session -t $SESSION"
